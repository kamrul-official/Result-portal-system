-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 27, 2022 at 11:03 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ResultPortal`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `CourseCode` varchar(7) NOT NULL,
  `CourseName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`CourseCode`, `CourseName`) VALUES
('GE-235', 'Principles of Accounting, Business & Economics'),
('None', 'None'),
('SE-222', 'Computer Architecture'),
('SE-231', 'System Analysis & Design Project'),
('SE-232', 'Operating System & System Programing'),
('SE-233', 'Operating System & System Programing Lab'),
('SE-234', 'Theory of Computing'),
('SE-532', 'Introduction to Robotics');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `ID` varchar(15) DEFAULT NULL,
  `Semester` varchar(15) DEFAULT NULL,
  `Course_1` varchar(15) DEFAULT 'None',
  `Course_1_mark` varchar(5) DEFAULT '0',
  `Course_2` varchar(15) DEFAULT 'None',
  `Course_2_mark` varchar(5) DEFAULT '0',
  `Course_3` varchar(15) DEFAULT 'None',
  `Course_3_mark` varchar(5) DEFAULT '0',
  `Course_4` varchar(15) DEFAULT 'None',
  `Course_4_mark` varchar(5) DEFAULT '0',
  `Course_1_cr` varchar(5) DEFAULT '0',
  `Course_2_cr` varchar(5) DEFAULT '0',
  `Course_3_cr` varchar(5) DEFAULT '0',
  `Course_4_cr` varchar(5) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`ID`, `Semester`, `Course_1`, `Course_1_mark`, `Course_2`, `Course_2_mark`, `Course_3`, `Course_3_mark`, `Course_4`, `Course_4_mark`, `Course_1_cr`, `Course_2_cr`, `Course_3_cr`, `Course_4_cr`) VALUES
('211-35-3162', 'Spring-2022', 'SE-221', '85', 'SE-222', '68', 'SE-223', '74', 'SE-224', '45', '1', '3', '3', '3'),
('211-35-3162', 'Summer-2022', 'SE-315', '74', 'SE-314', '85', 'SE-313', '96', 'None', '0', '3', '3', '1', '0'),
('211-35-3155', 'Spring-2022', 'SE-221', '74', 'SE-222', '15', 'SE-223', '85', 'None', '0', '3', '3', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `Semester_Name` varchar(15) NOT NULL,
  `OrderBy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`Semester_Name`, `OrderBy`) VALUES
('Spring-2020', 1),
('Summer-2020', 2),
('Fall-2020', 3),
('Spring-2021', 4),
('Summer-2021', 5),
('Fall-2021', 6),
('Spring-2022', 7),
('Summer-2022', 8),
('Fall-2022', 9);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `ID` varchar(15) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Degree` varchar(6) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL,
  `Batch` varchar(5) DEFAULT NULL,
  `Gender` varchar(8) DEFAULT NULL,
  `Contact` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`ID`, `Name`, `Degree`, `Department`, `Batch`, `Gender`, `Contact`) VALUES
('211-33-3265', 'nadia', 'MSc', 'Software Engineering', '04', 'Female', '2556456'),
('211-35-002', 'Khalid', 'MSc', 'Software Engineering', '34', 'Male', '017412586'),
('211-35-3155', 'Beniamine Nahid', 'BSc', 'Software Engineering', '34', 'Male', '01784080922'),
('211-35-3160', 'Abdullah', 'BSc', 'Software Engineering', '34', 'Male', '01712345678'),
('211-35-3162', 'Ashik', 'BSc', 'Software Engineering', '10', 'Male', '012345684656');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` varchar(15) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Phone` varchar(15) NOT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `UserType` varchar(10) NOT NULL,
  `SecurityQ` varchar(500) DEFAULT NULL,
  `SecurityQA` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Name`, `Phone`, `Email`, `Password`, `CourseCode`, `UserType`, `SecurityQ`, `SecurityQA`) VALUES
('10001', 'Kashem', '01234567891', 'kashem@yahoo.com', '10001', 'GE-235', 'Teacher', 'What is your name', 'kashem'),
('10002', 'Rabbi', '01734567891', 'rabbi@gmail.com', '10002', 'None', 'Admin', 'What is your pet animal?', 'cat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`CourseCode`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD KEY `ID` (`ID`),
  ADD KEY `Semester` (`Semester`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`Semester_Name`),
  ADD UNIQUE KEY `OrderBy` (`OrderBy`),
  ADD UNIQUE KEY `Semester_Name` (`Semester_Name`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CourseCode` (`CourseCode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `OrderBy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `student` (`ID`),
  ADD CONSTRAINT `result_ibfk_2` FOREIGN KEY (`Semester`) REFERENCES `semester` (`Semester_Name`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`CourseCode`) REFERENCES `courses` (`CourseCode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
